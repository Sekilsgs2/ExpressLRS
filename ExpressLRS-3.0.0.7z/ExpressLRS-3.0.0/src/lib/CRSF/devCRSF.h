#pragma once

#include "device.h"
#include "POWERMGNT.h"
#include "CRSF.h"

extern device_t CRSF_device;
extern void crsfRCFrameAvailable();
