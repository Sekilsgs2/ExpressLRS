#include "elrs_eeprom.h"
#include "targets.h"
#include "logging.h"

#if !defined(TARGET_NATIVE)
#if defined(PLATFORM_STM32)
    #if defined(TARGET_USE_EEPROM) && defined(USE_I2C)
        #if !defined(TARGET_EEPROM_ADDR)
            #define TARGET_EEPROM_ADDR 0x51
            #warning "!! Using default EEPROM address (0x51) !!"
        #endif

        #include <Wire.h>
        #include <extEEPROM.h>
        extEEPROM EEPROM(kbits_2, 1, 1, TARGET_EEPROM_ADDR);
    #else
        #define STM32_USE_FLASH
        #include <utility/stm32_eeprom.h>
    #endif
#elif defined(PLATFORM_ASR6601)
	#define STM32_USE_FLASH
#else
    #include <EEPROM.h>
#endif

void
ELRS_EEPROM::Begin()
{
        eeprom_buffer_fill();
}

uint8_t
ELRS_EEPROM::ReadByte(const uint32_t address)
{
    if (address >= RESERVED_EEPROM_SIZE)
    {
        // address is out of bounds
        ERRLN("EEPROM address is out of bounds");
        return 0;
    }
    return eeprom_buffered_read_byte(address);
}

void
ELRS_EEPROM::WriteByte(const uint32_t address, const uint8_t value)
{
    if (address >= RESERVED_EEPROM_SIZE)
    {
        // address is out of bounds
        ERRLN("EEPROM address is out of bounds");
        return;
    }
    eeprom_buffered_write_byte(address, value);
}

void
ELRS_EEPROM::Commit()
{
	int ret = 0;
	DBGLN("Start commit");
	
	ret = eeprom_buffer_flush();
    if (ret != 0) {
		DBGLN("EEPROM commit failed %d", ret);
	}
	
    else
		DBGLN("EEPROM commit success %d", ret);
}

#endif /* !TARGET_NATIVE */