#pragma once

#include "device.h"

extern device_t Backpack_device;
